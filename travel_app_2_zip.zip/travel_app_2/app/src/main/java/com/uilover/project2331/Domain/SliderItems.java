package com.uilover.project2331.Domain;

public class SliderItems {
    private String url;

    public SliderItems() {
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
